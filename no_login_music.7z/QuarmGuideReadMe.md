1. Extract these files into the root of your TAKP folder, overwriting your existing files. 

2. Make sure your eqclient.ini has EnableClassicMusic=FALSE

These files replace your sound files with versions that have the sound muted, but are the same file size as the originals. The eqclient.ini value forces the game to use these new sounds instead of the old midi sounds. When you log in next time, it should now be silent.